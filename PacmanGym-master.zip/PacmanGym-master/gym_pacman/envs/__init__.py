from gym_pacman.envs.pacman_env import PacmanEnv
